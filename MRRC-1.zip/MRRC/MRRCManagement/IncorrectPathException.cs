﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    /// <summary>
    /// 
    /// Custom exception class that is thrown when an incorrect file path is provided in args 
    /// (not ..\..\..\Data) 
    /// 
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    public class IncorrectPathException : Exception
    {
        // exception constructor that takes a mesage as parameter
        public IncorrectPathException(String message) : base(message)
        {
        }
    }
}
