﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace MRRCManagement
{
    /// <summary>
    /// 
    /// Class for that grabs the input string returned from ReadKey Method in the Keys Class
    /// and validates it, will provide error messages and continue until the user inputs correctly
    /// 
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    class Validation
    {
        // read and validate and return strings allowing only letters
        // menu parameter is passed down to the ReadKeys(menu) which determines
        // which menu to go back to when the LEFT arrow key is pressed
        // this is the same for all other validate methods 
        // read and validate and return, strings allowing only letters
        public static string ReadAlphabeticalString(string menu)
        {
            string input;
            bool alphabetTest = false;
            // continues reading until user enters a valid input 
            do
            {
                input = Hotkeys.ReadKeys(menu);
                // using regular expressions to check whether the input is alphabet 
                alphabetTest = Regex.IsMatch(input, @"^[a-zA-Z]+$");
                if (!alphabetTest)
                {
                    Console.WriteLine("Please enter a value with only letters");
                }
            }
            while (!alphabetTest);
            return input;
        }

        // read and validate and return, strings allowing letters, numbers and spaces
        public static string ReadAlphanumericString(string menu)
        {
            string input;
            bool validAlphanumeric = false;
            do
            {
                input = Hotkeys.ReadKeys(menu);
                validAlphanumeric = Regex.IsMatch(input, @"^[a-zA-Z0-9_ ]+$");
                if (!validAlphanumeric)
                {
                    Console.WriteLine("Please enter a value with only numbers or letters");
                }
            }
            while (!validAlphanumeric);
            return input;
        }

        // read and validate registration to have 3 numbers followed by 3 letters
        // and for the vehicle registration to currently exist in the vehicle list
        public static string ReadRegistration(string menu)
        {
            string input;
            bool validRegistration = false;
            do
            {
                input = Hotkeys.ReadKeys(menu);
                validRegistration = Regex.IsMatch(input, @"^\d{3}[a-zA-Z]{3}$");
                if (!validRegistration)
                {
                    Console.WriteLine("Please enter a value with 3 Numbers followed by 3 capitalised letters");
                }
                else if (!Fleet.CheckVehicleExist(input))
                {
                    Console.WriteLine("A vehicle with this registration does not exist");
                    validRegistration = false;
                }
                else
                {
                    validRegistration = true;
                }
            }
            while (!validRegistration);
            return input;
        }

        // read and validate registration to have 3 numbers followed by 3 letters
        // and for the vehicle to not currently exist, overloaded from ReadRegistration
        public static string ReadRegistration(string menu, bool unique)
        {
            string input;
            bool validRegistration = unique;
            do
            {
                input = Hotkeys.ReadKeys(menu);
                validRegistration = Regex.IsMatch(input, @"^\d{3}[a-zA-Z]{3}$");
                if (!validRegistration)
                {
                    Console.WriteLine("Please enter a value with 3 Numbers followed by 3 capitalised letters");
                }
                else if (Fleet.CheckVehicleExist(input))
                {
                    Console.WriteLine("A vehicle with this registration already exists");
                    validRegistration = false;
                }
                else
                {
                    validRegistration = true;
                }
            }
            while (!validRegistration);
            return input;
        }

        // read and validate a customer ID for selecting a ID
        // only allows numbers and ID that exists in the customer list
        public static int ReadCustomerID(string menu)
        {
            bool validCustomerID;
            int output;
            do
            {
                string option = Hotkeys.ReadKeys(menu);
                validCustomerID = int.TryParse(option, out output);
                // checks if output from Tryparse is a number
                if (!validCustomerID)
                {
                    Console.WriteLine("Please enter a valid 'number'");
                }
                // check if output is greater than 0 
                else if (output < 0)
                {
                    validCustomerID = false;
                    Console.WriteLine("Please enter a positive number");
                }
                // check if customer with that ID exists
                else if (!CRM.CheckCustomerExist(output))
                {
                    Console.WriteLine("A customer with that ID does not exist");
                    validCustomerID = false;
                }
            }
            while (!validCustomerID);
            return output;
        }

        // read and validate and return Gender, only allows values from Gender ENUM
        // case insensitive
        public static Gender ReadGender(string menu)
        {
            bool validGender;
            string input;
            Gender output;
            do
            {
                input = Hotkeys.ReadKeys(menu);
                validGender = Gender.TryParse(input, true, out output);
                if (!validGender)
                {
                    Console.WriteLine("Please enter a valid gender 'Male', 'Female' or 'Other'");
                }
                // prevents int values of enums outside of the enum values to work (only 0,1,2 will work)
                if (!Enum.IsDefined(typeof(Gender), output))
                {
                    Console.WriteLine("Please enter a valid gender 'Male', 'Female' or 'Other'");
                    validGender = false;
                } 
            }
            while (!validGender);
            return output;
        }

        // read and validate transmission types, only allows values from TransmissionType ENUM
        public static TransmissionType ReadTransmission(string menu)
        {
            bool validTransmission;
            string input;
            TransmissionType output;
            do
            {
                input = Hotkeys.ReadKeys(menu);
                // tries to parse the input from the user, and returns an output if the user entered a Gender from the Gender ENUM
                validTransmission = TransmissionType.TryParse(input, true, out output);
                if (!validTransmission)
                {
                    Console.WriteLine("Please enter a valid transmission type 'Manual' or 'Automatic'");
                }
                if (!Enum.IsDefined(typeof(TransmissionType), output))
                {
                    Console.WriteLine("Please enter a valid transmission type 'Manual' or 'Automatic'");
                    validTransmission = false;
                }
            }
            while (!validTransmission);
            return output;
        }

        // read and validate fuel types, only allows values from FuelType ENUM
        public static FuelType ReadFuel(string menu)
        {
            bool validFuelType;
            string input;
            FuelType output;
            do
            {
                input = Hotkeys.ReadKeys(menu);
                validFuelType = FuelType.TryParse(input, true, out output);
                if (!validFuelType)
                {
                    Console.WriteLine("Please enter a valid fuel type 'Petrol' or 'Diesel'");
                }
                if (!Enum.IsDefined(typeof(FuelType), output))
                {
                    Console.WriteLine("Please enter a valid fuel type 'Petrol' or 'Diesel'");
                    validFuelType = false;
                }
            }
            while (!validFuelType);
            return output;
        }

        // read and validate and return dates
        public static DateTime ReadDate(string menu)
        {
            bool validDate;
            string input;
            DateTime output;
            do
            {
                input = Hotkeys.ReadKeys(menu);
                validDate = DateTime.TryParse(input, out output);
                if (!validDate)
                {
                    Console.WriteLine("Please enter an appropriate date e.g. '06/09/2001'");
                }
            }
            while (!validDate);
            return output;
        }

        // read and validate and return integers for menu options enterred
        // numOptions determines how many menu options exist
        // only allows numbers above 0 AND that do not exceed numOptions
        // overloaded method - ReadNumber
        public static int ReadNumber(int numOptions, string menu)
        {
            bool validInt;
            int output;
            do
            {
                string option = Hotkeys.ReadKeys(menu);
                validInt = int.TryParse(option, out output);
                // checks if output from Tryparse is a number
                if (!validInt)
                {
                    Console.WriteLine("Please enter a valid 'number'");

                }
                // check if output is between valid numbers e.g. if there's 4 options value should be between 1-4 
                else if (output > numOptions || output < 1)
                {
                    validInt = false;
                    Console.WriteLine("Please enter a number betwen 1 and {0}", numOptions);
                }
            }
            while (!validInt);
            return output;
        }

        // read and validate and return integers in general
        // only allows numbers above 0 
        // overloaded method - ReadNumber
        public static int ReadNumber(string menu)
        {
            bool validInt;
            int output;
            do
            {
                string option = Hotkeys.ReadKeys(menu);
                validInt = int.TryParse(option, out output);
                if (!validInt)
                {
                    Console.WriteLine("Please enter a valid 'number'");
                }
                else if (output < 0)
                {
                    validInt = false;
                    Console.WriteLine("Please enter a positive number");
                }
            }
            while (!validInt);
            return output;
        }

        // read, validate and return double 
        // only allows above 0 
        // overloaded method - ReadNumber
        public static double ReadNumber(string menu, bool isDouble)
        {
            bool validDouble;
            double output;
            do
            {
                string option = Hotkeys.ReadKeys(menu);
                validDouble = double.TryParse(option, out output);
                if (!validDouble)
                {
                    Console.WriteLine("Please enter a valid number e.g. 10 or 10.00 or 9.99");
                }
                else if (output < 0)
                {
                    validDouble = false;
                    Console.WriteLine("Please enter a positive number");
                }
            }
            while (!validDouble);
            return output;
        }

        // reads, validate and return boolean 
        public static bool ReadBool(string menu)
        {
            bool validBool;
            bool output;
            do
            {
                string input = Hotkeys.ReadKeys(menu);
                validBool = Boolean.TryParse(input, out output);
                if (!validBool)
                {
                    Console.WriteLine("Please enter a either true or false");
                }
            }
            while (!validBool);
            return output;
        }
    }
}
