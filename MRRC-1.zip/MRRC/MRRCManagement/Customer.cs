﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    public enum Gender
    {
        Male,
        Female,
        Other
    }
    /// <summary>
    /// 
    /// Customer class that creates provides constructor for a customer object
    /// and methods for the class
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    public class Customer
    {
        public int CustomerID { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public Gender CustomerGender { get; set; }
        public DateTime DOB { get; set; }

        // default customer object constructor if no values are parsed in
        public Customer()
        {
        }

        // overloaded constructor for customer (used when values are parsed into constructor arguments)
        public Customer(int ID, string title, string firstName, string lastName, Gender gender, DateTime DOB)
        {
            CustomerID = ID;
            Title = title;
            FirstName = firstName;
            LastName = lastName;
            CustomerGender = gender;
            this.DOB = DOB;
        }

        // returns a string when object is called containing its attributes
        public override string ToString()
        {
            return string.Concat("customer #", CustomerID, " ", Title, " ", FirstName,
                                 " ", LastName, " - Gender: ", CustomerGender, " DOB: ", DOB.ToString("dd/MM/yyyy"));
        }
    }
}
