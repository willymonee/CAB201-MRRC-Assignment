﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    /// <summary>
    /// 
    /// CRM class that holds methods regarding the Customer object
    /// adding, deleting, modifying and displaying customers
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    public class CRM
    {
        const char DELIM = ',';
        public static List<Customer> Customers { get; set; } = new List<Customer>();

        // retrieve all customers from customers list and display them formatted in a table
        public static void DisplayCustomers()
        {
            if (Customers.Count > 0)
            {
                Console.WriteLine("\nDISPLAYING CUSTOMERS");
                Console.WriteLine("\n{0,-4} {1,-9} {2,-15} {3,-15} {4,-10} {5,-15}", "ID", "Title", "First Name",
                                  "Last Name", "Gender", "Date of Birth");
                Console.WriteLine("_________________________________________________________________________________\n");
                for (int i = 0; i < Customers.Count; i++)
                {

                    Console.WriteLine("{0,-4}| {1,-9}| {2,-13}| {3,-13}| {4,-8}| {5,-23} |", Customers[i].CustomerID,
                                      Customers[i].Title, Customers[i].FirstName, Customers[i].LastName,
                                      Customers[i].CustomerGender, Customers[i].DOB);
                }
                Console.WriteLine("_________________________________________________________________________________");
            }
            else
            {
                Console.WriteLine("\nNo customers to display yet");
            }
        }

        // method to check if customer exists returns true if customer exist
        // compares the inputted id argument against  all ids in the customer list
        public static bool CheckCustomerExist(int id)
        {
            bool customerExist;
            if (Customers.Exists(x => x.CustomerID == id))
            {
                customerExist = true;
            }
            else
            {
                customerExist = false;
            }
            return customerExist;
        }

        // return the max id within the customers list
        private static int FindMaxID(List<Customer> list)
        {
            int maxID = 0;
            // checks each customer in the List to see if their ID is greater than the current maxID 
            foreach (Customer customer in list)
            {
                if (customer.CustomerID > maxID)
                {
                    maxID = customer.CustomerID;
                }
            }
            return maxID;
        }

        // create a customer and add them to the customer list, then write to customer file
        public static void AddCustomer()
        {
            // Customer ID is current max ID in customers list + 1
            int id = FindMaxID(Customers) + 1;
            // assign values entered by user as parameters for the Customer constructor
            Console.WriteLine("\nADD CUSTOMER - or press left arrow key to return to customer management menu\n");
            Console.WriteLine("Enter title: ");
            string title = Validation.ReadAlphabeticalString("Customer Menu");
            Console.WriteLine("Enter first name: ");
            string firstName = Validation.ReadAlphabeticalString("Customer Menu");
            Console.WriteLine("Enter last name: ");
            string lastName = Validation.ReadAlphabeticalString("Customer Menu");
            Console.WriteLine("Enter gender: ");
            Gender gender = Validation.ReadGender("Customer Menu");
            Console.WriteLine("Enter Date of Birth: ");
            DateTime dob = Validation.ReadDate("Customer Menu");
            // create the customer and update the .csv file
            Customer createdCustomer = new Customer(id, title, firstName, lastName, gender, dob);
            Customers.Add(createdCustomer);
            Console.WriteLine("\nSuccessfully added {0}", createdCustomer);
            SaveToFile();
        }

        // returns the customer with selected ID or goes back to main menu if no customers exist yet 
        private static Customer GetCustomer()
        {
            if (Customers.Count != 0)
            {
                Console.WriteLine("Select ID of customer:");
                int queryID = Validation.ReadCustomerID("Customer Menu");
                // finds the customer object with that ID number and returns it 
                Customer queriedCustomer = Customers.Find(customer => customer.CustomerID == queryID);
                return queriedCustomer;
            }
            else
            {
                Console.WriteLine("No customers exist yet");
                Menu.CustomerMenu();
                return null;
            }
        }

        // remove the customer selected via ID, and write to the file accordingly
        public static void RemoveCustomer()
        {
            Console.WriteLine("\nREMOVE CUSTOMER - or press left arrow key to return to customer management menu\n");
            Customer removedCustomer = GetCustomer();
            if (Fleet.CustomerIsRenting(removedCustomer.CustomerID))
            {
                Console.WriteLine("\nCannot remove customer #{0} as they are currently renting a vehicle"
                                  , removedCustomer.CustomerID);
            }
            else
            {
                Customers.Remove(removedCustomer);
                Console.WriteLine("\nSuccessfully deleted {0}", removedCustomer);
                SaveToFile();
            }
        }

        // edit the selected customer's ID, title, firstname, lastname and gender
        // write to the file the changes
        public static void ModifyCustomer()
        {
            Console.WriteLine("\nMODIFY CUSTOMER - or press left arrow key to return to customer management menu\n");
            Customer modifiedCustomer = GetCustomer();
            Console.WriteLine("\nModifying: {0}", modifiedCustomer);
            Console.WriteLine("Modify title:");
            modifiedCustomer.Title = Validation.ReadAlphabeticalString("Customer Menu");
            Console.WriteLine("Modify first name:");
            modifiedCustomer.FirstName = Validation.ReadAlphabeticalString("Customer Menu");
            Console.WriteLine("Modify last name:");
            modifiedCustomer.LastName = Validation.ReadAlphabeticalString("Customer Menu");
            Console.WriteLine("Modify gender:");
            modifiedCustomer.CustomerGender = Validation.ReadGender("Customer Menu");
            Console.WriteLine("Modify DOB:");
            modifiedCustomer.DOB = Validation.ReadDate("Customer Menu");
            SaveToFile();
            Console.WriteLine("\nSuccessfully modified to {0}", modifiedCustomer);
        }

        // method to create a new CSV and insert customers ~ is called whenever list is changed from customer added, modified or deleted
        // code adapted from ppt slides from reading and writing file lecture
        private static void SaveToFile()
        {
            string customerFileName = Files.fileNames[0].CustomerFile;
            FileStream outFile = new FileStream(customerFileName, FileMode.Create, FileAccess.Write);
            StreamWriter writer = new StreamWriter(outFile);
            writer.WriteLine("ID" + DELIM + "Title" + DELIM + "FirstName" + DELIM + "LastName" + DELIM + "Gender" +
                             DELIM + "Date");
            //write each row with customer attributes for each customer
            foreach (Customer customer in Customers)
            {
                writer.WriteLine(customer.CustomerID.ToString() + DELIM + customer.Title + DELIM + customer.FirstName +
                                 DELIM + customer.LastName + DELIM + customer.CustomerGender + DELIM + customer.DOB);
            }
            writer.Close();
            outFile.Close();
        }

        // Read customers.csv file and add objects to list based on contents of file
        // or create a new customer.csv if the file does not exist
        // code adapted from ppt slides from reading and writing file lecture
        public static void LoadCustomersFromFile(string file)
        {
            if (File.Exists(file))
            {
                // create new file stream and stream reader
                FileStream inFile = new FileStream(file, FileMode.Open, FileAccess.Read);
                StreamReader reader = new StreamReader(inFile);
                string recordIn;
                string[] fields; 
                recordIn = reader.ReadLine();
                // skips reading the 1st line in the CSV which is a header row 
                recordIn = reader.ReadLine();
                while (recordIn != null)
                {
                    // create a new customer that will be updated with values read from file
                    Customer createdCustomer = new Customer();
                    fields = recordIn.Split(DELIM);
                    createdCustomer.CustomerID = Int32.Parse(fields[0]);
                    createdCustomer.Title = fields[1];
                    createdCustomer.FirstName = fields[2];
                    createdCustomer.LastName = fields[3];
                    string genderCSVInput = fields[4];
                    Gender gender;
                    Gender.TryParse(genderCSVInput, out gender);
                    createdCustomer.CustomerGender = gender;
                    createdCustomer.DOB = DateTime.Parse(fields[5]);
                    Customers.Add(createdCustomer);
                    recordIn = reader.ReadLine();
                }
                reader.Close();
                inFile.Close();
            }
            else
            {
                // create a new file
                FileStream outFile = new FileStream(file, FileMode.Create, FileAccess.Write);
                StreamWriter writer = new StreamWriter(outFile);
                writer.Close();
                outFile.Close();
                // find the index where the last '\' is at in the filename and substring from that point
                int index = file.LastIndexOf(@"\") + 1;
                throw new FileNotFoundException(file.Substring(index) + " file does not exist yet, and will be automatically created\n");
            }
        }
    }
}
