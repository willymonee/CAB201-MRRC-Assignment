﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    /// <summary>
    /// 
    /// Custom exception class that is thrown when there are mismatched parenthesis both right and left
    /// e.g. either '(RED or blue' or 'RED or blue)' both would throw an exception
    /// 
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    public class ShuntingYardException : Exception
    {
        // exception constructor that takes a mesage as parameter
        public ShuntingYardException(string message)
           : base(message)
        {
        }
    }
}
