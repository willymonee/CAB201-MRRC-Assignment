﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    /// <summary>
    /// 
    /// Custom exception class that is thrown when there are no search results returned
    /// 
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    class SearchException : Exception
    {
        // exception constructor that takes a mesage as parameter
        public SearchException(string message)
           : base(message)
        {
        }
    }
}
