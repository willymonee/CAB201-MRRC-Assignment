﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    /// <summary>
    /// 
    /// Inherited class from the parent class 'Vehicle'
    /// Creates a vehicle with a VehicleGrade of commericial
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    class CommercialVehicle : Vehicle
    {
        /// Constructor with a series of default and non-default
        /// parameters associated with the commercial grade
        /// Assigns the vehicle object attributes based on argument values
        public CommercialVehicle(string registration, string make, string model, int year,
                                 int numSeats = 4, TransmissionType transmission = TransmissionType.Manual,
                                 FuelType fuel = FuelType.Diesel, bool GPS = false, bool sunRoof = false,
                                 double dailyRate = 130, string colour = "black")
        {
            VehicleRego = registration;
            Grade = VehicleGrade.Commercial;
            Make = make;
            Model = model;
            Year = year;
            NumSeats = numSeats;
            Transmission = transmission;
            Fuel = fuel;
            this.GPS = GPS;
            SunRoof = sunRoof;
            DailyRate = dailyRate;
            Colour = colour;
            StringNumSeats = numSeats + "-Seater";
            if (SunRoof)
            {
                StringSunRoof = "sunroof";
            }
            else
            {
                StringSunRoof = "no sunroof";
            }
            if (GPS)
            {
                StringGPS = "GPS";
            }
            else
            {
                StringGPS = "no GPS";
            }
        }
    }
}
