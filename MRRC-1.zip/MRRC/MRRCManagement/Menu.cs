﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    /// <summary>
    /// 
    /// Menu class deals with what displays in the console application initially
    /// and navigates user, enabling them to use methods 
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    public class Menu
    {
        // const values for menu options in switch statements
        const int CUSTOMER_MENU = 1;
        const int FLEET_MENU = 2;
        const int RENTAL_MENU = 3;
        const int DISPLAY_CUSTOMER = 1;
        const int ADD_CUSTOMER = 2;
        const int MODIFY_CUSTOMER = 3;
        const int DELETE_CUSTOMER = 4;
        const int DISPLAY_FLEET = 1;
        const int ADD_VEHICLE = 2;
        const int MODIFY_VEHICLE = 3;
        const int DELETE_VEHICLE = 4;
        const int DISPLAY_RENTAL = 1;
        const int SEARCH_VEHICLE = 2;
        const int RENT_VEHICLE = 3;
        const int RETURN_VEHICLE = 4;
        const int PRECEDENCE = 2;
        const int NO_PRECEDENCE = 1;
         
        // initial welcome message
        public static void WelcomeMessage()
        {
            Console.WriteLine("### Mates-Rates Rent-a-Car Operation Menu ###");
            Console.WriteLine("**********************************************");
            Console.WriteLine("Press the ESC key at any time to exit. Press the HOME key to return to the main menu. " 
                             + "Press the LEFT ARROW key to return to the previous menu.");
        }

        // main menu 
        public static void MainMenu()
        {
            Console.WriteLine("");
            Console.WriteLine("[ MAIN MENU ]\n");
            Console.WriteLine("Please enter a number from the options below OR ESC to exit:\n");
            Console.WriteLine("1) Customer Management");
            Console.WriteLine("2) Fleet Management");
            Console.WriteLine("3) Rental Management\n");
            NavigateMenu("Main Menu");
        }

        // customer menu
        public static void CustomerMenu()
        {
            Console.WriteLine("");
            Console.WriteLine("[ CUSTOMER MANAGEMENT MENU ]\n");
            Console.WriteLine("Please enter a number from the options below " +
                              "or press ESC to exit or HOME key to return to main menu\n");
            Console.WriteLine("1) Display Customers");
            Console.WriteLine("2) New Customer");
            Console.WriteLine("3) Modify Customer");
            Console.WriteLine("4) Delete Customer");
            NavigateMenu("Customer Management Menu");
        }

        // fleet menu
        public static void FleetMenu()
        {
            Console.WriteLine("");
            Console.WriteLine("[ FLEET MANAGEMENT MENU ]\n");
            Console.WriteLine("Please enter a number from the options below " +
                              "or press ESC to exit or HOME key to return to main menu\n");
            Console.WriteLine("1) Display Fleet");
            Console.WriteLine("2) New Vehicle");
            Console.WriteLine("3) Modify Vehicle");
            Console.WriteLine("4) Delete Vehicle");
            NavigateMenu("Fleet Management Menu");
        }

        // rental menu
        public static void RentalMenu()
        {
            Console.WriteLine("");
            Console.WriteLine("[ RENTAL MANAGEMENT MENU ]\n");
            Console.WriteLine("Please enter a number from the options below " +
                              "or press ESC to exit or HOME key to return to main menu\n");
            Console.WriteLine("1) Display Rentals");
            Console.WriteLine("2) Search Vehicles");
            Console.WriteLine("3) Rent Vehicle");
            Console.WriteLine("4) Return Vehicle");
            NavigateMenu("Rental Management Menu");
        }

        // menu navigation that navigates depending on user input and which menu currently in
        // parameter menu determines which menu to return back to when LEFT ARROW key is entered
        // see Hotkeys class for LEFT ARROW key implementation
        private static void NavigateMenu(string menu)
        {
            int menuOption;
            if (menu == "Main Menu")
            {
                menuOption = Validation.ReadNumber(3, menu);
                //switch statement to determine which menu to navigate to depending on what number inputted
                switch (menuOption)
                {
                    case CUSTOMER_MENU:
                        CustomerMenu();
                        break;
                    case FLEET_MENU:
                        FleetMenu();
                        break;
                    case RENTAL_MENU:
                        RentalMenu();
                        break;
                }
            }
            // menu option for the customer management 
            else if (menu == "Customer Management Menu")
            {
                Console.WriteLine("");
                menuOption = Validation.ReadNumber(4, "Main Menu");
                // displaying, adding, modifying or deleting a customer, then return back to the Customer Menu 
                switch (menuOption)
                {
                    case DISPLAY_CUSTOMER:
                        CRM.DisplayCustomers();
                        CustomerMenu();
                        break;
                    case ADD_CUSTOMER:
                        CRM.AddCustomer();
                        CustomerMenu();
                        break;
                    case MODIFY_CUSTOMER:
                        CRM.ModifyCustomer();
                        CustomerMenu();
                        break;
                    case DELETE_CUSTOMER:
                        CRM.RemoveCustomer();
                        CustomerMenu();
                        break;
                }
            }
            // menu option for Fleet Management Menu
            else if (menu == "Fleet Management Menu")
            {
                Console.WriteLine("");
                menuOption = Validation.ReadNumber(4, "Main Menu");
                // displaying, adding, modifying, deleting a vehicle, then return back to fleet menu
                switch (menuOption)
                {
                    case DISPLAY_FLEET:
                        Fleet.DisplayFleet();
                        FleetMenu();
                        break;
                    case ADD_VEHICLE:
                        Fleet.AddVehicle();
                        FleetMenu();
                        break;
                    case MODIFY_VEHICLE:
                        Fleet.ModifyVehicle();
                        FleetMenu();
                        break;
                    case DELETE_VEHICLE:
                        Fleet.RemoveVehicle();
                        FleetMenu();
                        break;
                }
            }
            // menu option for Rental Management
            else if (menu == "Rental Management Menu")
            {
                Console.WriteLine("");
                menuOption = Validation.ReadNumber(4, "Main Menu");
                // display, search, rent or return vehicle, then return back to rental menu
                switch (menuOption)
                {
                    case DISPLAY_RENTAL:
                        try
                        {
                            Fleet.DisplayRentals();
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        RentalMenu();
                        break;
                    case SEARCH_VEHICLE:
                        Console.WriteLine("\nSEARCH VEHICLES - or press left arrow key to return to rental menu\n");
                        Console.WriteLine("Choose precedence:");
                        Console.WriteLine("1) AND and OR have equal precedence");
                        Console.WriteLine("2) AND has higher precedence over OR\n");
                        try
                        {
                            int precedenceOption = Validation.ReadNumber(2, "Rental Menu");
                            // query the user, converting the query into infix tokens, then infix to postfix
                            List<Token> infixTokens = Search.ParseQuery(Search.Query());
                            List<Token> postfixTokens = new List<Token>();
                            //precedence is indicated
                            if (precedenceOption == PRECEDENCE)
                            {
                                postfixTokens = Search.ShuntingYard(infixTokens, true);
                            }
                            //precedence not indicated
                            else
                            {
                                postfixTokens = Search.ShuntingYard(infixTokens);
                            }
                            //perform search function on postfix tokens
                            Search.SearchVehicles(postfixTokens);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        RentalMenu();
                        break;
                    case RENT_VEHICLE:
                        Fleet.RentVehicle();
                        RentalMenu();
                        break;
                    case RETURN_VEHICLE:
                        try
                        {
                            Fleet.ReturnVehicle();
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        RentalMenu();
                        break;
                }
            }
        }
    }
}
