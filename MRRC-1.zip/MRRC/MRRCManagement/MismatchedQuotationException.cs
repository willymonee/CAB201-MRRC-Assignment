﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    /// <summary>
    /// 
    /// Custom exception class that is thrown when there quotation marks for queries are mismatched
    /// e.g. the query 'RED OR "Fierro 240' would trigger this exception as Fierro 240 is fully wrapped
    /// in double quotations
    /// 
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    class MismatchedQuotationException : Exception
    {
        //exception constructor that takes a mesage as parameter
        public MismatchedQuotationException(string message)
           : base(message)
        {
        }
    }
}
