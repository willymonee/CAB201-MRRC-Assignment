﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    public enum VehicleGrade
    {
        Undefined,
        Economy,
        Family,
        Luxury,
        Commercial
    }
    public enum TransmissionType
    {
        Automatic,
        Manual
    }
    public enum FuelType
    {
        Petrol,
        Diesel
    }
    /// <summary>
    /// 
    /// Parent class of the Vehicle objects 
    /// Sets common attributes & methods for all vehicle objects
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    public abstract class Vehicle
    {
        public VehicleGrade Grade { get; set; }
        public string VehicleRego { get; set; }
        public string Make { get; set; }
        public int Year { get; set; }
        public int NumSeats { get; set; }
        public string Model { get; set; }
        public TransmissionType Transmission { get; set; }
        public FuelType Fuel { get; set; }
        public bool GPS { get; set; }
        public bool SunRoof { get; set; }
        public double DailyRate { get; set;}
        public string Colour { get; set; }
        public string StringSunRoof { get; set; }
        public string StringGPS { get; set; }
        public string StringNumSeats { get; set; }
    
        // method to convert the object to a string of its attributes
        // and return it when called
        public override string ToString()
        {
            return string.Concat( VehicleRego, " ", Make, " ", Model, 
                                 " ", Year, ", Grade: ", Grade, ", Seats: ", StringNumSeats,
                                 ", Transmission Type: ", Transmission, ", Fuel Type: " , Fuel, ", GPS: ", StringGPS,
                                 ", Sunroof: ", StringSunRoof, ", Daily Rate: ", DailyRate.ToString("C"), ", Colour: ", Colour);
        }
    }
}
