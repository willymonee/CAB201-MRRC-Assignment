﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    /// <summary>
    /// 
    /// Parent class for tokens used in RPN
    /// 
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    public interface Token
    {
    }
}
