﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    /// <summary>
    /// 
    /// Custom exception class that is thrown when an incorrect file type is provided
    /// in args (not csv format) 
    /// 
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    public class IncorrectFileTypeException : Exception
    {
        // exception constructor that takes a mesage as parameter
        public IncorrectFileTypeException(String message) : base(message)
        {
        }
    }
}
