﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    /// <summary>
    /// 
    /// Files class creates a file object that holds the 3 file names provided by the command line argument
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    public class Files
    {
        // list that holds the files object
        public static List<Files> fileNames = new List<Files>();
        public string CustomerFile { get; set; }
        public string VehicleFile { get; set; }
        public string RentalFile { get; set; }

        // constructor for files objects that takes the customer.csv, vehicle.csv and rental.csv file
        // as string parameters
        public Files(string customerFile, string vehicleFile, string rentalFile)
        {
            CustomerFile = customerFile;
            VehicleFile = vehicleFile;
            RentalFile = rentalFile;
        }
    }
}
