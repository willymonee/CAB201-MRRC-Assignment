﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    /// <summary>
    /// 
    /// Custom exception class that is thrown when there are not enough operators in a query
    /// e.g. RED OR BLUE YELLOW
    /// 
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    class MissingOperatorException : Exception
    {
        //exception constructor with paramater containing a message
        public MissingOperatorException(string message)
           : base(message)
        {
        }
    }
}
