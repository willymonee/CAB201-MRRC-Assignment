﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    /// <summary>
    /// 
    /// Custom exception class that is thrown when there are insufficient attributes for operators to operate on
    /// e.g. the query 'Red AND' would trigger this exception
    /// 
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    class EvaluatorException : Exception
    {
        // exception constructor that takes a mesage as an argument
        public EvaluatorException(string message)
           : base(message)
        {
        }
    }
}
