﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace MRRCManagement
{
    /// <summary>
    /// 
    /// Key class used to read all key inputs made by the user
    /// and determine what occurs as a result
    /// Author: William Ee 2020 
    /// ReadLine or ReadKeys code adapted from: https://stackoverflow.com/questions/8789646/using-readline-and-readkey-simultaneously by: Overlord Zurg
    /// 
    /// </summary>
    public class Hotkeys
    {
        // method either works like Console.ReadLine OR it handles special keys 
        public static string ReadKeys(string menu)
        {
            string typedKeys = "";
            int currentKeyIndex = 0;
            // continues reading each key until the enter button is hit
            do
            {
                // reads each key 
                ConsoleKeyInfo readKeyResult = Console.ReadKey(true);

                // handle Esc --> exits the program and returns nothing 
                if (readKeyResult.Key == ConsoleKey.Escape)
                {
                    Environment.Exit(0);
                    return null;
                }
                // handle Enter -->  returns the string currently typed out
                if (readKeyResult.Key == ConsoleKey.Enter)
                {
                    Console.WriteLine();
                    return typedKeys;
                }
                // handle Home Key --> returns the user back to the main menu with welcome message
                if (readKeyResult.Key == ConsoleKey.Home)
                {
                    Console.WriteLine("\nReturning back to...");
                    Menu.MainMenu();
                }
                // handle Left Arrow --> returns to the previous primary menu
                // the 'menu' parameter in the ReadKey method is used to determine
                // which menu to go back to when the left arrow key is pressed
                if (readKeyResult.Key == ConsoleKey.LeftArrow)
                {
                    if (menu == "Customer Menu")
                    {
                        Console.WriteLine("\nReturning back to...");
                        Menu.CustomerMenu();
                    }
                    else if (menu == "Main Menu")
                    {
                        Console.WriteLine("\nReturning back to...");
                        Menu.MainMenu();
                    }
                    else if (menu == "Fleet Menu")
                    {
                        Console.WriteLine("\nReturning back to...");
                        Menu.FleetMenu();
                    }
                    else if (menu == "Rental Menu")
                    {
                        Console.WriteLine("\nReturning back to...");
                        Menu.RentalMenu();
                    }
                }
               
                // handle backspace to enable the removal of entered keys
                // removes the previous key from the string
                // displays visually an empty space replacing the previously
                // entered key
                // decrements the key index as there is one less key 
                if (readKeyResult.Key == ConsoleKey.Backspace)
                {
                    //only works if the user has entered a key to remove the key from string & change the output on screen
                    //preventing the currentKeyIndex going negative 
                    if (currentKeyIndex > 0)
                    {
                        typedKeys = typedKeys.Remove(typedKeys.Length - 1);
                        Console.Write(readKeyResult.KeyChar);
                        Console.Write(" ");
                        Console.Write(readKeyResult.KeyChar);
                        currentKeyIndex--;
                    }
                }
                // handle all other keypresses --> adds each key entered to the string and writes out each entered key 
                // mimics Console.ReadLine()
                else
                {
                    // adds the entered key to the current string as long as it is not backspace 
                    // (prevents the backspace key from being added to string)
                    if (readKeyResult.Key != ConsoleKey.Backspace)
                    {
                        typedKeys += readKeyResult.KeyChar;
                        Console.Write(readKeyResult.KeyChar);
                    }
                    currentKeyIndex++;
                }
            }
            while (true);
        }
    }
}
