﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    /// <summary>
    /// 
    /// Inherited class from the parent interface 'Token'
    /// Creates a RightParenthesis Token
    /// 
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    class RightParenthesisToken : Token
    {
        public override string ToString()
        {
            return ")";
        }
    }
}
