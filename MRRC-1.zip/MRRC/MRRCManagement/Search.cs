﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    /// <summary>
    /// 
    /// Search class that holds methods for querying a user for attributes
    /// then finding vehicles fitting the query
    /// 
    /// Code has been adapted from AMS 10 Simple Calculator for RPN and WK10 search lecture demonstrations for search functionality
    /// Code to separate by spaces unless they are within quotation marks adapted from:
    /// https://stackoverflow.com/questions/14655023/split-a-string-that-has-white-spaces-unless-they-are-enclosed-within-quotes
    /// by user Cedric Bignon Jan 9 2016 
    /// 
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    public class Search
    {
        public static List<string> UnrentedRegistrations = new List<string>();

        // method to ask user for a query and return query as a string
        public static string Query()
        {         
            Console.WriteLine("\nEnter query:");
            string query = Hotkeys.ReadKeys("Rental Menu");
            return query;
        }

        // method to convert user inputted query into a list of infix tokens to return
        public static List<Token> ParseQuery(string query)
        {
            string spacedQuery = query.ToUpper();
            int quotationMarkCount = spacedQuery.ToCharArray().Count(c => c == '"');
            if (quotationMarkCount % 2 != 0)
            {
                throw new MismatchedQuotationException("\nInvalid query - Mismatched quotation marks in query");
            }
            // splits the query string using a quotation mark as a delimitter, and then projects each split section into a new sequence of values
            // e.g. The query "fierro 244" OR Red  will have a projected sequence of  {' ', 0} {fierro 244, 1}, {Red OR, 2}
            List<string> tokens = query.Split('"').Select((token, index) => index % 2 == 0  
                // if the index is even, first pad spaces before and after parenthesis, then split the values where there are spaces 
                ? token.Replace("(", " ( ").Replace(")", " ) ").Split(' ').Where(x => !string.IsNullOrEmpty(x)) 
                // if the index is odd then leave the values together in a string array
                : new string[] { token })  
                // projects values back into the original order provided by the query and put them into the tokens list
                .SelectMany(token => token).ToList();
            // then convert the string of tokens into a list of token objects
            List<Token> infixTokens = new List<Token>();
            foreach (string token in tokens)
            {
                if (token.ToUpper() == "AND")
                {
                    infixTokens.Add(new OperatorToken(token.ToUpper(), 2));
                }
                else if (token.ToUpper() == "OR")
                {
                    infixTokens.Add(new OperatorToken(token.ToUpper(), 1));
                }
                else if (token == "(")
                {
                    infixTokens.Add(new LeftParenthesisToken());
                }
                else if (token == ")")
                {
                    infixTokens.Add(new RightParenthesisToken());
                }
                else 
                {
                    infixTokens.Add(new AttributeToken(token.ToUpper()));
                }
            }
            return infixTokens;
        }

        // method of converting infix tokens to postfix tokens to be evaluated
        // does not compare precendences as operators have equal precedence
        public static List<Token> ShuntingYard(List<Token> infixTokens)
        {
            List<Token> postfixTokens = new List<Token>();
            Stack<Token> operatorStack = new Stack<Token>();
            foreach (Token token in infixTokens)
            {
                if (token is AttributeToken)
                {
                    postfixTokens.Add(token);
                }
                else if (token is OperatorToken)
                {   // moving to output all operators, then put current operator onto the stack
                    while (operatorStack.Any() && operatorStack.Peek() is OperatorToken)
                    {
                        postfixTokens.Add(operatorStack.Pop());
                    }
                    operatorStack.Push(token); //put current operator onto the stack
                }
                else if (token is LeftParenthesisToken)
                {   // push left parenthesis onto stack
                    operatorStack.Push(token);
                }
                else if (token is RightParenthesisToken)
                {   // pop all operators off the stack until the matching left parenthesis is found
                    // checks to see if there is a corresponding left parenthesis in the stack
                    while (operatorStack.Count > 0 && !(operatorStack.Peek() is LeftParenthesisToken))
                    {
                        postfixTokens.Add(operatorStack.Pop());
                    }
                    if (operatorStack.Count == 0)
                    {
                        throw new ShuntingYardException("\nSearch failed - Missing matching left parenthesis");   
                    }
                    operatorStack.Pop();
                }
            }
            // move last token on operator stack 
            while (operatorStack.Any())
            {
                if (operatorStack.Peek() is LeftParenthesisToken)
                {
                    throw new ShuntingYardException("\nSearch failed - Missing matching right parenthesis");
                }
                postfixTokens.Add(operatorStack.Pop());
            }
            return postfixTokens;
        }

        // overloaded method of converting infix tokens to postfix tokens to be evaluated
        // AND and OR operators have the different precedence in this method and will have precedence compared
        public static List<Token> ShuntingYard(List<Token> infixTokens, bool precedence)
        {
            List<Token> postfixTokens = new List<Token>();
            Stack<Token> operatorStack = new Stack<Token>();
            foreach (Token token in infixTokens)
            {
                if (token is AttributeToken)
                {
                    postfixTokens.Add(token);
                }
                else if (token is OperatorToken)
                {   // moving to output all higher or equal priority operators, then put current operator onto the stack
                    while (operatorStack.Any() && operatorStack.Peek() is OperatorToken
                        && ((OperatorToken)operatorStack.Peek()).Precedence >= ((OperatorToken)token).Precedence)
                    {
                        postfixTokens.Add(operatorStack.Pop());
                    }
                    operatorStack.Push(token);
                }
                else if (token is LeftParenthesisToken)
                {   // push left parenthesis onto stack
                    operatorStack.Push(token);
                }
                else if (token is RightParenthesisToken)
                {   // pop all operators off the stack until the matching left parenthesis is found
                    // checks to see if there is a corresponding left parenthesis in the stack
                    while (operatorStack.Count > 0 && !(operatorStack.Peek() is LeftParenthesisToken))
                    {
                        postfixTokens.Add(operatorStack.Pop());
                    }
                    if (operatorStack.Count == 0)
                    {
                        throw new ShuntingYardException("\nSearch failed - Missing matching left parenthesis");
                    }
                    operatorStack.Pop();
                }
            }
            // move last token on operator stack 
            while (operatorStack.Any())
            {
                if (operatorStack.Peek() is LeftParenthesisToken)
                {
                    throw new ShuntingYardException("\nSearch failed - Missing matching right parenthesis");
                }
                postfixTokens.Add(operatorStack.Pop());
            }
            return postfixTokens;
        }

        // method to return a list of strings which represent each attribute of unrented vehicles
        private static List<string> GetAttributeList()
        {
            List<string> attributesList = new List<string>();
            foreach (Vehicle vehicle in Fleet.Vehicles)
            {
                if (!Fleet.VehicleIsRented(vehicle.VehicleRego))
                {
                    //attributesList.Add(vehicle.VehicleRego);
                    attributesList.Add(vehicle.Make);
                    attributesList.Add(vehicle.Model);
                    attributesList.Add(vehicle.Grade.ToString());
                    attributesList.Add(vehicle.Colour);
                    attributesList.Add(vehicle.Transmission.ToString());
                    attributesList.Add(vehicle.Fuel.ToString());
                    attributesList.Add(vehicle.StringSunRoof);
                    attributesList.Add(vehicle.StringGPS);
                    attributesList.Add(vehicle.StringNumSeats);
                    attributesList.Add(vehicle.Year.ToString());
                }
            }
            // convert all attributes to upper case & remove all duplicate attributes from the list
            attributesList = attributesList.ConvertAll(attribute => attribute.ToUpper());
            List<string> uniqueAttributesList = attributesList.Distinct().ToList();
            return uniqueAttributesList;
        }

        // method to create a sorted list containing the attributes from attibute list as keys
        // and values containing a hashset containing vehicle registrations that have those attributes
        private static SortedList GetAttributeSet()
        {
            SortedList attributeSets = new SortedList();
            int idx;
            HashSet<string> hs;
            // add attributes(keys) with empty hashset(value)
            foreach (string attribute in GetAttributeList())
            {
                attributeSets.Add(attribute, new HashSet<string>());
            }
            // add an additional key and empty value to the list for attributes queried that do not exist
            attributeSets.Add("non-existent", new HashSet<string>());
            idx = attributeSets.IndexOfKey("non-existent");
            hs = (HashSet<string>)attributeSets.GetByIndex(idx);
            hs.Add("");
            attributeSets.SetByIndex(idx, hs);
            // for each vehicle, add its registration to an attribute set it has, unless it is renting
            foreach (Vehicle vehicle in Fleet.Vehicles)
            {
                if (!Fleet.VehicleIsRented(vehicle.VehicleRego))
                {
                    idx = attributeSets.IndexOfKey(vehicle.Colour.ToUpper());
                    if (idx >= 0)
                    {   // here if Colour set found
                        hs = (HashSet<string>)attributeSets.GetByIndex(idx);
                        hs.Add(vehicle.VehicleRego); //add to set
                        attributeSets.SetByIndex(idx, hs); // update set with added registration
                    }
                    idx = attributeSets.IndexOfKey(vehicle.Make.ToUpper());
                    if (idx >= 0)
                    {   // here if Make set found
                        hs = (HashSet<string>)attributeSets.GetByIndex(idx);
                        hs.Add(vehicle.VehicleRego); //add to set
                        attributeSets.SetByIndex(idx, hs); // update set with added registration
                    }
                    idx = attributeSets.IndexOfKey(vehicle.Fuel.ToString().ToUpper());
                    if (idx >= 0)
                    {   // here if Fuel set found
                        hs = (HashSet<string>)attributeSets.GetByIndex(idx);
                        hs.Add(vehicle.VehicleRego); // add to set
                        attributeSets.SetByIndex(idx, hs); // update set with added registration
                    }
                    idx = attributeSets.IndexOfKey(vehicle.Model.ToUpper());
                    if (idx >= 0)
                    {   // here if Model set found
                        hs = (HashSet<string>)attributeSets.GetByIndex(idx);
                        hs.Add(vehicle.VehicleRego); // add to set
                        attributeSets.SetByIndex(idx, hs); // update set with added registration
                    }
                    idx = attributeSets.IndexOfKey(vehicle.Grade.ToString().ToUpper());
                    if (idx >= 0)
                    {   // here if Grade set found
                        hs = (HashSet<string>)attributeSets.GetByIndex(idx);
                        hs.Add(vehicle.VehicleRego); // add to set
                        attributeSets.SetByIndex(idx, hs); // update set with added registration
                    }
                    idx = attributeSets.IndexOfKey(vehicle.StringGPS.ToUpper());
                    if (idx >= 0)
                    {   // here if GPS set found
                        hs = (HashSet<string>)attributeSets.GetByIndex(idx);
                        hs.Add(vehicle.VehicleRego); // add to set
                        attributeSets.SetByIndex(idx, hs); // update set with added registration
                    }
                    idx = attributeSets.IndexOfKey(vehicle.StringSunRoof.ToUpper());
                    if (idx >= 0)
                    {   // here if Sunroof set found
                        hs = (HashSet<string>)attributeSets.GetByIndex(idx);
                        hs.Add(vehicle.VehicleRego); // add to set
                        attributeSets.SetByIndex(idx, hs); // update set with added registration
                    }
                    idx = attributeSets.IndexOfKey(vehicle.StringNumSeats.ToUpper());
                    if (idx >= 0)
                    {   // here if Numseats set found
                        hs = (HashSet<string>)attributeSets.GetByIndex(idx);
                        hs.Add(vehicle.VehicleRego); // add to set
                        attributeSets.SetByIndex(idx, hs); // update set with added registration
                    }
                    idx = attributeSets.IndexOfKey(vehicle.Transmission.ToString().ToUpper());
                    if (idx >= 0)
                    {   // here if Transmission set found
                        hs = (HashSet<string>)attributeSets.GetByIndex(idx);
                        hs.Add(vehicle.VehicleRego); // add to set
                        attributeSets.SetByIndex(idx, hs); // update set with added registration
                    }
                    idx = attributeSets.IndexOfKey(vehicle.Year.ToString());
                    if (idx >= 0)
                    {   // here if Year set found
                        hs = (HashSet<string>)attributeSets.GetByIndex(idx);
                        hs.Add(vehicle.VehicleRego); // add to set
                        attributeSets.SetByIndex(idx, hs); // update set with added registration
                    }
                }
            }
            return attributeSets;
        }
     
        // method to evaluate postfix tokens supplied in argument to return results from query
        public static void SearchVehicles(List<Token> postfixTokens)
        {
            Stack setStack = new Stack(); // stack to hold hashset of results
            HashSet<string> hs1 = new HashSet<string>(); // second attribute
            HashSet<string> hs2 = new HashSet<string>(); // first attribute
            HashSet<string> hs = new HashSet<string>(); // temporary set to hold results
            SortedList attributeSets = GetAttributeSet();
            String[] temp = new string[] { };
            int idx;
            string[] result = new string[] { };
            if (postfixTokens.Count == 0)
            {   // no query entered then return all unrented registrations
                foreach (Vehicle vehicle in Fleet.Vehicles)
                {
                    if (!Fleet.VehicleIsRented(vehicle.VehicleRego))
                    {
                        UnrentedRegistrations.Add(vehicle.VehicleRego);
                    }
                }
                result = UnrentedRegistrations.ToArray();
                Console.Write("Showing all unrented vehicles...");
            }
            else
            {
                foreach (Token token in postfixTokens)
                {
                    if (token is OperatorToken)
                    {
                        if (((OperatorToken)token).Name == "AND")
                        {   // pop two sets off the stack and apply Intersect, push back result
                            if (setStack.Count < 2)
                            {
                                throw new EvaluatorException("\nInvalid query - Not enough attributes for AND to operate on");
                            }
                            hs1 = (HashSet<string>)setStack.Pop();
                            hs2 = (HashSet<string>)setStack.Pop();
                            temp = hs1.ToArray<string>(); // copy the elements of the set hs1
                            hs = new HashSet<string>(temp); // make a deep copy of hs1
                            hs.IntersectWith(hs2); // apply the intersect
                            setStack.Push(hs); // push reference to stack
                        }
                        else
                        {   // pop two sets off the stack and apply union
                            if (setStack.Count < 2)
                            {
                                throw new EvaluatorException("\nInvalid query - Not enough attributes for OR to operate on");
                            }
                            hs1 = (HashSet<string>)setStack.Pop();
                            hs2 = (HashSet<string>)setStack.Pop();
                            temp = hs1.ToArray<string>(); // copy elements of the set hs1
                            hs = new HashSet<string>(temp); // make a deep copy of hs1
                            hs.UnionWith(hs2); // apply the union 
                            setStack.Push(hs); // push reference back on the stack
                        }
                    }
                    else
                    {   // if value is an operand/attribute
                        string attribute = ((AttributeToken)token).Attribute;
                        idx = attributeSets.IndexOfKey(attribute);
                        if (idx >= 0)
                        {
                            hs1 = (HashSet<string>)attributeSets.GetByIndex(idx);
                            setStack.Push(hs1);
                        }
                        else
                        {   // value is not an attribute that exists within the vehicle lists
                            // push a hashset containing an empty string onto the stack so that it can continue with queries
                            // e.g. black or asdfasdf should still find black vehicles
                            hs1 = (HashSet<string>)attributeSets.GetByIndex(attributeSets.IndexOfKey("non-existent"));
                            setStack.Push(hs1);
                            Console.WriteLine("\nThe attribute {0} is not found in the unrented vehicle's set", attribute);
                        }
                    }
                }
                if (setStack.Count == 1)
                {   
                    hs1 = (HashSet<string>)setStack.Pop();
                    result = hs1.ToList().ToArray(); // convert hashset into a list then into an array
                }
                else
                {
                    throw new MissingOperatorException("\nInvalid query - Missing operator/operators either AND or OR");
                }
            }
            result = result.Where(x => !string.IsNullOrEmpty(x)).ToArray(); // remove any empty strings (from attributes that do not exist)
            string resultString = string.Join(", ", result); // create a string that joins the array values separated by commas
            if (result.Length == 0)
            {
                throw new SearchException("\nNo results returned"); 
            }
            else
            {
                Console.WriteLine("\nSearch results: " + resultString);
            }
        }
    }
}
