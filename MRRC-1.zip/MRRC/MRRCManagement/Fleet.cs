﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    /// <summary>
    /// 
    /// Fleet class that contains methods regarding the vehicle object
    /// such as adding, modifying, deleting or displaying vehicles
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    public class Fleet
    {
        // constants for the fleet menu 
        const int ECONOMY = 1;
        const int FAMILY = 2;
        const int LUXURY = 3;
        const int COMMERCIAL = 4;
        const int DEFAULT = 1;
        // constant for writing and reading from file to switch rows
        const char DELIM = ',';
        public static Dictionary<string, int> RentalsList = new Dictionary<string, int>();
        public static List<Vehicle> Vehicles { get; set; } = new List<Vehicle>();
        // method to check if customer exists returns true if customer exist
        // compares the inputted rego against the regos in the Vehicles List
        public static bool CheckVehicleExist(string registration)
        {
            bool vehicleExist;
            if (Vehicles.Exists(x => x.VehicleRego == registration.ToUpper()))
            {
                vehicleExist = true;
            }
            else
            {
                vehicleExist = false;
            }
            return vehicleExist;
        }

        // display vehicles in the list in table format 
        public static void DisplayFleet()
        {
            if (Vehicles.Count > 0)
            {
                Console.WriteLine("\nDisplaying Vehicles\n");
                Console.WriteLine("{0,-9} {1,-13} {2,-15} {3,-13} {4,-9} {5,-9} {6,-14} {7,-11}" +
                                  "{8,-10} {9,-11} {10,-11} {11,-10}", "Rego", "Grade",
                                  "Make", "Model", "Year", "NumSeats", "Transmission", "Fuel", "GPS",
                                  "SunRoof", "DailyRate", "Colour");
                Console.WriteLine("_________________________________________________________________________________" +
                                  "__________________________________________________________________\n");

                for (int i = 0; i < Vehicles.Count; i++)
                {

                    Console.WriteLine("{0,-8} | {1,-10} | {2,-13} | {3,-13} | {4,-6} | {5,-7} | {6,-12} | {7,-8} |" +
                                      "{8,-7} | {9,-10} | {10,-10} | {11,-10} |", Vehicles[i].VehicleRego, Vehicles[i].Grade,
                                      Vehicles[i].Make, Vehicles[i].Model, Vehicles[i].Year, Vehicles[i].NumSeats,
                                      Vehicles[i].Transmission, Vehicles[i].Fuel, Vehicles[i].StringGPS,
                                      Vehicles[i].StringSunRoof, Vehicles[i].DailyRate, Vehicles[i].Colour);
                }
                Console.WriteLine("_________________________________________________________________________________" +
                                 "__________________________________________________________________");
            }
            else
            {
                Console.WriteLine("\nNo vehicles to display yet");
            }
        }

        // method to add new vehicle - contains methods which create new vehicle objects depending on vehicle grade
        public static void AddVehicle()
        {
            // add vehicle menu 
            Console.WriteLine("\nADD VEHICLE - or press left arrow key to return to vehicle menu\n");
            Console.WriteLine("Select vehicle grade: ");
            Console.WriteLine("1) Economy");
            Console.WriteLine("2) Family");
            Console.WriteLine("3) Luxury");
            Console.WriteLine("4) Commercial\n");
            int menuOption = Validation.ReadNumber(4, "Fleet Menu");
            //choose which grade of vehicle to be added 
            switch (menuOption)
            {
                case ECONOMY:
                    CreateVehicle(VehicleGrade.Economy);
                    break;
                case FAMILY:
                    CreateVehicle(VehicleGrade.Family);
                    break;
                case LUXURY:
                    CreateVehicle(VehicleGrade.Luxury);
                    break;
                case COMMERCIAL:
                    CreateVehicle(VehicleGrade.Commercial);
                    break;
            }
        }

        // function to create a new vehicle object dependent on the vehicle grade
        // parameter is used to determine which vehicle child constructor is used
        private static void CreateVehicle(VehicleGrade grade)
        {
            Console.WriteLine("\nSelect whether to use default values or enter all values: ");
            Console.WriteLine("1) Default");
            Console.WriteLine("2) Enter all values\n");
            int option = Validation.ReadNumber(2, "Fleet Menu");
            // option for default values to be used
            if (option == DEFAULT)
            {
                // user assigns values to attribute parameters
                Console.WriteLine("\nEnter car rego:");
                string registration = Validation.ReadRegistration("Fleet Menu", true);
                registration = registration.ToUpper();
                Console.WriteLine("Enter car make:");
                string make = Validation.ReadAlphabeticalString("Fleet Menu");
                Console.WriteLine("Enter car model:");
                string model = Validation.ReadAlphanumericString("Fleet Menu");
                Console.WriteLine("Enter year:");
                int year = Validation.ReadNumber("Fleet Menu");
                // constructor using default values, and adding to list
                if (grade == VehicleGrade.Luxury)
                {
                    Vehicle addedVehicle = new LuxuryVehicle(registration, make, model, year);
                    Console.WriteLine("\nSuccessfully added {0}", addedVehicle);
                    Vehicles.Add(addedVehicle);
                }
                else if (grade == VehicleGrade.Commercial)
                {
                    Vehicle addedVehicle = new CommercialVehicle(registration, make, model, year);
                    Console.WriteLine("\nSuccessfully added {0}", addedVehicle);
                    Vehicles.Add(addedVehicle);
                }
                else if (grade == VehicleGrade.Economy)
                {
                    Vehicle addedVehicle = new EconomyVehicle(registration, make, model, year);
                    Console.WriteLine("\nSuccessfully added {0}", addedVehicle);
                    Vehicles.Add(addedVehicle);
                }
                else if (grade == VehicleGrade.Family)
                {
                    Vehicle addedVehicle = new FamilyVehicle(registration, make, model, year);
                    Console.WriteLine("\nSuccessfully added {0}", addedVehicle);
                    Vehicles.Add(addedVehicle);
                }
              
            }
            // option for user to enter all attributes for vehicle
            else
            {
                // user assigns values to attribute parameters
                Console.WriteLine("\nEnter car rego:");
                string registration = Validation.ReadRegistration("Fleet Menu", true);
                registration = registration.ToUpper();
                Console.WriteLine("Enter car make:");
                string make = Validation.ReadAlphabeticalString("Fleet Menu");
                Console.WriteLine("Enter car model:");
                string model = Validation.ReadAlphanumericString("Fleet Menu");
                Console.WriteLine("Enter year:");
                int year = Validation.ReadNumber("Fleet Menu");
                Console.WriteLine("Enter number of seats");
                int numSeats = Validation.ReadNumber("Fleet Menu");
                Console.WriteLine("Enter transmission type");
                TransmissionType transmission = Validation.ReadTransmission("Fleet Menu");
                Console.WriteLine("Enter fuel type");
                FuelType fuel = Validation.ReadFuel("Fleet Menu");
                Console.WriteLine("Enter whether car has GPS true or false");
                bool gps = Validation.ReadBool("Fleet Menu");
                Console.WriteLine("Enter whether car has sun roof true or false");
                bool sunRoof = Validation.ReadBool("Fleet Menu");
                Console.WriteLine("Enter daily rate");
                double dailyRate = Validation.ReadNumber("Fleet Menu", true);
                Console.WriteLine("Enter colour");
                string colour = Validation.ReadAlphabeticalString("Fleet Menu");
                // constructor with all values, and adding to list
                if (grade == VehicleGrade.Luxury)
                {
                    Vehicle addedVehicle = new LuxuryVehicle(registration, make, model, year, numSeats,
                                                            transmission, fuel, gps, sunRoof, dailyRate, colour);
                    Console.WriteLine("\nSuccessfully added {0}", addedVehicle);
                    Vehicles.Add(addedVehicle);
                }
                else if (grade == VehicleGrade.Economy)
                {
                    Vehicle addedVehicle = new EconomyVehicle(registration, make, model, year, numSeats,
                                                             transmission, fuel, gps, sunRoof, dailyRate, colour);
                    Console.WriteLine("\nSuccessfully added {0}", addedVehicle);
                    Vehicles.Add(addedVehicle);
                }
                else if (grade == VehicleGrade.Family)
                {
                    Vehicle addedVehicle = new FamilyVehicle(registration, make, model, year, numSeats,
                                                            transmission, fuel, gps, sunRoof, dailyRate, colour);
                    Console.WriteLine("\nSuccessfully added {0}", addedVehicle);
                    Vehicles.Add(addedVehicle);
                }
                else if (grade == VehicleGrade.Commercial)
                {
                    Vehicle addedVehicle = new CommercialVehicle(registration, make, model, year, numSeats,
                                                                transmission, fuel, gps, sunRoof, dailyRate, colour);
                    Console.WriteLine("\nSuccessfully added {0}", addedVehicle);
                    Vehicles.Add(addedVehicle);
                }
            }
            // update addition to CSV file
            SaveVehiclesToFile();
        }

        // selects the vehicle with the inputted rego
        // OR returns to the fleet menu if there are no vehicles yet
        // argument of menu determines which menu to return back to when left arrow is pressed
        private static Vehicle GetVehicle(string menu)
        {
            if (Vehicles.Count != 0)
            {
                Console.WriteLine("Select car registration:");
                string registration = Validation.ReadRegistration(menu);
                registration = registration.ToUpper();
                //finds a vehicle with the same rego as the input
                Vehicle queriedVehicles = Vehicles.Find(item => item.VehicleRego == registration);
                return queriedVehicles;
            }
            else
            {
                Console.WriteLine("No vehicles exist yet");
                Menu.FleetMenu();
                return null;
            }
        }

        // deletes the vehicle with the selected ID
        public static void RemoveVehicle()
        {
            if (Vehicles.Count > 0)
            {
                Console.WriteLine("\nREMOVE VEHICLE - or press left arrow key to return to vehicle menu\n");
                Vehicle removedVehicle = GetVehicle("Fleet Menu");
                if (VehicleIsRented(removedVehicle.VehicleRego))
                {
                    Console.WriteLine("\nVehicle {0} cannot be removed as it is currently being rented", removedVehicle.VehicleRego);
                }
                else
                {
                    Vehicles.Remove(removedVehicle);
                    Console.WriteLine("\nSuccessfully deleted {0}", removedVehicle.VehicleRego);
                    SaveVehiclesToFile();
                }     
            }
            else
            {
                Console.WriteLine("No vehicles exist to remove yet");
            }
        }

        // modifies the attributes of the vehicle with the selected registration
        public static void ModifyVehicle()
        {
            if (Vehicles.Count > 0)
            {
                Console.WriteLine("\nMODIFY VEHICLE - or press left arrow key to return to vehicle menu\n");
                // gets and modifies the selected vehicle
                Vehicle modifiedVehicle = GetVehicle("Fleet Menu");
                Console.WriteLine("\nModifying: {0}", modifiedVehicle);
                Console.WriteLine("Modify make:");
                modifiedVehicle.Make = Validation.ReadAlphabeticalString("Fleet Menu");
                Console.WriteLine("Modify car model:");
                modifiedVehicle.Model = Validation.ReadAlphanumericString("Fleet Menu");
                Console.WriteLine("Modify year:");
                modifiedVehicle.Year = Validation.ReadNumber("Fleet Menu");
                Console.WriteLine("Modify number of seats");
                modifiedVehicle.NumSeats = Validation.ReadNumber("Fleet Menu");
                Console.WriteLine("Modify transmission type");
                modifiedVehicle.Transmission = Validation.ReadTransmission("Fleet Menu");
                Console.WriteLine("Modify fuel type");
                modifiedVehicle.Fuel = Validation.ReadFuel("Fleet Menu");
                Console.WriteLine("Modify whether car has GPS true or false");
                modifiedVehicle.GPS = Validation.ReadBool("Fleet Menu");
                Console.WriteLine("Modify whether car has sun roof true or false");
                modifiedVehicle.SunRoof = Validation.ReadBool("Fleet Menu");
                Console.WriteLine("Modify daily rate");
                modifiedVehicle.DailyRate = Validation.ReadNumber("Fleet Menu", true);
                Console.WriteLine("Modify colour");
                modifiedVehicle.Colour = Validation.ReadAlphabeticalString("Fleet Menu");
                Console.WriteLine("\nSuccessfully modified {0}", modifiedVehicle.VehicleRego);
                // writes updates to file
                SaveVehiclesToFile();
            }
            else
            {
                Console.WriteLine("No vehicles exist yet to modify");
            }
        }

        // method to create and write to CSV file 
        private static void SaveVehiclesToFile()
        {
            // new file stream and stream writer
            FileStream outFile = new FileStream(Files.fileNames[0].VehicleFile, FileMode.Create, FileAccess.Write);
            StreamWriter writer = new StreamWriter(outFile);
            // write the header
            writer.WriteLine("Registration" + DELIM + "Grade" + DELIM + "Make" + DELIM + "Model" + DELIM + "Year"
                            + DELIM + "NumSeats" + DELIM + "Transmission" + DELIM + "Fuel" + DELIM + "GPS"
                            + DELIM + "SunRoof" + DELIM + "DailyRate" + DELIM + "Colour");
            // write values in each row 
            foreach (Vehicle vehicle in Vehicles)
            {
                writer.WriteLine(vehicle.VehicleRego + DELIM + vehicle.Grade + DELIM + vehicle.Make + DELIM +
                                 vehicle.Model + DELIM + vehicle.Year + DELIM + vehicle.NumSeats + DELIM +
                                 vehicle.Transmission + DELIM + vehicle.Fuel + DELIM + vehicle.GPS + DELIM +
                                 vehicle.SunRoof + DELIM + vehicle.DailyRate + DELIM + vehicle.Colour);
            }
            // close stream writer and file 
            writer.Close();
            outFile.Close();
        }

        // read the values in the csv file and load them as objects to the vehicle list
        // takes the filename (provided by args) from the file to be read as arguments
        public static void LoadVehiclesFromFile(string file)
        {
            if (File.Exists(file))
            {
                // new file stream and stream writer
                FileStream inFile = new FileStream(file, FileMode.Open, FileAccess.Read);
                StreamReader reader = new StreamReader(inFile);
                string recordIn;
                string[] fields;
                recordIn = reader.ReadLine();
                // skip the header line
                recordIn = reader.ReadLine();
                while (recordIn != null)
                {
                    // create values using each field to be assigned as parameters for the constructors
                    fields = recordIn.Split(DELIM);
                    VehicleGrade grade;
                    VehicleGrade.TryParse(fields[1], out grade);
                    string registration = fields[0];
                    string make = fields[2];
                    string model = fields[3];
                    int year = Int32.Parse(fields[4]);
                    int numSeats = Int32.Parse(fields[5]);
                    TransmissionType transmission;
                    TransmissionType.TryParse(fields[6], out transmission);
                    FuelType fuel;
                    FuelType.TryParse(fields[7], out fuel);
                    bool gps = bool.Parse(fields[8]);
                    bool sunRoof = bool.Parse(fields[9]);
                    double dailyRate = double.Parse(fields[10]);
                    string colour = fields[11];
                    // creates a commercial vehicle
                    if (grade == VehicleGrade.Commercial)
                    {
                        Vehicle createdVehicle = new CommercialVehicle(registration, make, model, year, numSeats,
                                            transmission, fuel, gps, sunRoof, dailyRate, colour);
                        Vehicles.Add(createdVehicle);

                    }
                    // creates a family vehicle
                    else if (grade == VehicleGrade.Family)
                    {
                        Vehicle createdVehicle = new FamilyVehicle(registration, make, model, year, numSeats,
                                            transmission, fuel, gps, sunRoof, dailyRate, colour);
                        Vehicles.Add(createdVehicle);
                    }
                    // creates a economy vehicle
                    else if (grade == VehicleGrade.Economy)
                    {

                        Vehicle createdVehicle = new EconomyVehicle(registration, make, model, year, numSeats,
                                                                    transmission, fuel, gps, sunRoof, dailyRate, colour);
                        Vehicles.Add(createdVehicle);
                    }
                    else if (grade == VehicleGrade.Luxury)
                    {   // creates a luxury vehicle
                        Vehicle createdVehicle = new LuxuryVehicle(registration, make, model, year, numSeats,
                                            transmission, fuel, gps, sunRoof, dailyRate, colour);
                        Vehicles.Add(createdVehicle);
                    }
                    // goes to the next row/line
                    recordIn = reader.ReadLine();
                }
                reader.Close();
                inFile.Close();
            }
            else
            {   // create a new file if no file exists
                int index = file.LastIndexOf(@"\") + 1;
                FileStream outFile = new FileStream(file, FileMode.Create, FileAccess.Write);
                StreamWriter writer = new StreamWriter(outFile);
                writer.Close();
                outFile.Close();
                throw new FileNotFoundException(file.Substring(index) + " file does not exist yet, and will be automatically created\n");
            }
        }
       
        // method to return the daily rate of the vehicle based on the registration provided in the argument
        private static double GetVehicleRate(string registration)
        {
            Vehicle rentedVehicle = Vehicles.Find(item => item.VehicleRego == registration);
            double rate = rentedVehicle.DailyRate;
            return rate;
        }
       
        // method to check if customer is currently renting a vehicle
        public static bool CustomerIsRenting(int queriedCustomer)
        {
            if (RentalsList.ContainsValue(queriedCustomer))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // method to check if a vehicle is currently being rented by a customer
        public static bool VehicleIsRented(string queriedRegistration)
        {
            if (RentalsList.ContainsKey(queriedRegistration))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // method to rent a car to a customer
        public static void RentVehicle()
        {
            Console.WriteLine("\nRENT VEHICLE - or press left arrow key to return to rental menu\n");
            string rentingVehicleRegistration;
            double rentingVehicleRate;
            // select registration if vehicle is not currently rented
            do
            {
                Vehicle rentVehicle = GetVehicle("Rental Menu");
                rentingVehicleRegistration = rentVehicle.VehicleRego;
                rentingVehicleRate = GetVehicleRate(rentingVehicleRegistration);
                if (VehicleIsRented(rentingVehicleRegistration))
                {
                    Console.WriteLine("{0} is already being rented. Please select another vehicle to rent", rentingVehicleRegistration);
                }
            }
            while (VehicleIsRented(rentingVehicleRegistration));
            int rentingCustomerID;
            // select customer id if customer is not currently renting
            do
            {
                Console.WriteLine("\nSelect customer to rent to:");
                rentingCustomerID = Validation.ReadCustomerID("Rental Menu");
                if (CustomerIsRenting(rentingCustomerID))
                {
                    Console.WriteLine("Customer #{0} is already renting a vehicle", rentingCustomerID);
                }
            }
            while (CustomerIsRenting(rentingCustomerID));
            // select amount of days to rent vehicle and multiply it by the daily rate to return total cost
            Console.WriteLine("\nSelect how many days to rent vehicle:");
            double numDays = Validation.ReadNumber("Rental Menu", true);
            double totalCost = numDays * rentingVehicleRate;
            // add to rental's list and print success message
            RentalsList.Add(rentingVehicleRegistration, rentingCustomerID);
            Console.WriteLine("\nSuccessfully renting {0} to customer #{1} for {2} days at a total cost of {3}"
                              , rentingVehicleRegistration, rentingCustomerID, numDays, totalCost.ToString("C2"));
            SaveRentalToFile();
        }

        // method to return a rented car from a customer only if the selected vehicle is currently being rented
        public static void ReturnVehicle()
        {
            if (RentalsList.Count == 0)
            {
                throw new NoRentalsException("\nThere are no rentals to return");
            }
            else
            {
                Console.WriteLine("\nRETURN VEHICLE - or press left arrow key to return to rental menu\n");
                bool validReturnRegistration;
                do
                {
                    string returnVehicleRegistration = GetVehicle("Rental Menu").VehicleRego;
                    if (VehicleIsRented(returnVehicleRegistration))
                    {   // remove selected vehicle
                        Console.WriteLine("\nSuccessfully returned {0} from customer #{1}", returnVehicleRegistration, RentalsList[returnVehicleRegistration]);
                        RentalsList.Remove(returnVehicleRegistration);
                        SaveRentalToFile();
                        validReturnRegistration = true;
                    }
                    else
                    {
                        Console.WriteLine("Vehicle is not currently being rented");
                        validReturnRegistration = false;
                    }
                } while (!validReturnRegistration);
            }
        }
         
        // method to produce a report of all rented vehicles and their customers in table format
        public static void DisplayRentals()
        {
            if (RentalsList.Count == 0)
            {
                throw new NoRentalsException("\nThere are no rentals to display");
            }
            else
            {
                Console.WriteLine("\nDISPLAYING RENTED VEHICLES");
                Console.WriteLine("\n{0,-13} {1,-9} {2,-5} ", "Registration", "Rate", "ID");
                Console.WriteLine("_______________________________\n");
                foreach (KeyValuePair<string, int> rental in RentalsList)
                {
                    double rate = GetVehicleRate(rental.Key);
                    Console.WriteLine(" {0,-12}| {1,-8}| {2,-5} |", rental.Key, rate.ToString("C2"), rental.Value);
                }
                Console.WriteLine("_______________________________");
            }
        }

        // method to update current rentals from dictionary to CSV
        private static void SaveRentalToFile()
        {
            FileStream outFile = new FileStream(Files.fileNames[0].RentalFile, FileMode.Create, FileAccess.Write);
            StreamWriter writer = new StreamWriter(outFile);
            writer.WriteLine("Registration" + DELIM + "CustomerID");
            foreach (KeyValuePair<string, int> rental in RentalsList)
            {
                writer.WriteLine(rental.Key + DELIM + rental.Value);
            }
            writer.Close();
            outFile.Close();
        }

        // method to load rentals CSV to rental dictionary
        // takes the filename (provided by args) from the file to be read as the parameter
        public static void LoadRentalsFromFile(string file)
        {
            if (File.Exists(file))
            {
                // create new file stream and stream reader
                FileStream inFile = new FileStream(file, FileMode.Open, FileAccess.Read);
                StreamReader reader = new StreamReader(inFile);
                string recordIn;
                string[] fields; 
                recordIn = reader.ReadLine();
                // skips reading the 1st line in the CSV which is a header row 
                recordIn = reader.ReadLine();
                while (recordIn != null)
                {
                    fields = recordIn.Split(DELIM);
                    string rentingVehicleRegistration = fields[0];
                    int rentingCustomerID = Int32.Parse(fields[1]);
                    // check conditions before adding vehicle in. This checking may not be necessary 
                    // under the assumption that vehicle, rental and customer files have data that is consistent with each other 
                    // e.g. if customer 1 is renting then customer 1 should be in the customer csv
                    if (CheckVehicleExist(rentingVehicleRegistration))
                    {
                        if (CRM.CheckCustomerExist(rentingCustomerID))
                        {
                            if (VehicleIsRented(rentingVehicleRegistration))
                            {
                                Console.WriteLine("Vehicle {0} is already being rented and will not be added to the rental list twice", rentingVehicleRegistration);
                            }
                            else if (CustomerIsRenting(rentingCustomerID))
                            {
                                Console.WriteLine("Customer {0} is already renting a vehicle and will not be added to the rentals list", rentingCustomerID);
                            }
                            else
                            {
                                RentalsList.Add(rentingVehicleRegistration, rentingCustomerID);
                            }
                        }
                        else
                        {
                            Console.WriteLine("Customer #{0} does not exist and will not be added to the rentals list", rentingCustomerID);
                        }      
                    }
                    else
                    {
                        Console.WriteLine("Vehicle: {0} does not exist and will not be added to the Rentals List", rentingVehicleRegistration);
                    }
                    recordIn = reader.ReadLine();
                }
                reader.Close();
                inFile.Close();
            }
            else
            {   // create a new file
                FileStream outFile = new FileStream(file, FileMode.Create, FileAccess.Write);
                StreamWriter writer = new StreamWriter(outFile);
                writer.Close();
                outFile.Close();
                // index marks where the final '\' is in the filename, allowing to substring the path to show only the filename
                int index = file.LastIndexOf(@"\") + 1;
                throw new FileNotFoundException(file.Substring(index) + " file does not exist yet, and will be automatically created\n");
            }
        }
    }
}
