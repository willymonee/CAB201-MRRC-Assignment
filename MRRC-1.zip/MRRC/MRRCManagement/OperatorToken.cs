﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    /// <summary>
    /// 
    /// Inherited class from the parent interface 'Token'
    /// Creates an Operator token for operators such as 'AND' and 'OR'
    /// 
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    class OperatorToken : Token
    {
        public string Name { get; set; } 
        public int Precedence { get; set; }
        public int SpecialPrecedence { get; set; }

        //constructor of token that takes the operator name and its precendence as arguments
        public OperatorToken(string name, int precedence)
        {
            Name = name;
            Precedence = precedence;
        }

        public override string ToString()
        {
            return Name;
        }
    }
}
