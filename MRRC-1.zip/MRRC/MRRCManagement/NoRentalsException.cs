﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    /// <summary>
    /// 
    /// Custom exception class that is thrown when the Rentals List is empty
    /// and the user tries to display rentals, or return a vehicle 
    /// which they are unable to do as no rentals exist
    /// 
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    class NoRentalsException : Exception
    {
        //exception constructor that takes a custom message as its parameter
        public NoRentalsException(String message) : base(message)
        {
        }
    }
}
