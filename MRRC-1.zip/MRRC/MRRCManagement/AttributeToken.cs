﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MRRCManagement
{
    /// <summary>
    /// 
    /// Inherited class from the parent interface 'Token'
    /// Creates an attribute Token which holds an attribute as a string
    /// 
    /// Author: William Ee 2020 
    /// 
    /// </summary>
    class AttributeToken : Token
    {
        public string Attribute { get; set; }

        // constructor for attribute token taking in the attribute name as an argument
        public AttributeToken(string attribute)
        {
            Attribute = attribute;
        }

        public override string ToString()
        {
            return Attribute.ToString();
        }
    }
}
