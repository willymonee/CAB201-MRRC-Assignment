﻿using System;
using MRRCManagement;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MMRC
{
    /// <summary>
    /// 
    ///Program class for running the console application  
    ///Reads data from csv files and inserts them into lists
    ///Displays a welcome message
    ///Runs the console application/Main menu
    ///
    /// </summary>
    class Program
    {
        //main program     
        static void Main(string[] args)
        {
            Console.SetWindowSize(150, 50);
            try
            {
                //checks each file name in the provided arguments that they are .csv files 
                //and lead to the ..\..\..\Data\ path
                foreach (string filename in args)
                {
                    if (!filename.EndsWith(".csv"))
                    {
                        throw new IncorrectFileTypeException("You have specified the incorrect file type, please use .csv, then re-run the program\n");
                    }
                    else if (!filename.StartsWith(@"..\..\..\Data\"))
                    {
                        throw new IncorrectPathException("You have specified the incorrect path, please specify the correct file parth then re-run the program\n");
                    }
                }
                //create a file object that holds filenames, and add it to a files List
                Files files = new Files(args[0], args[1], args[2]);
                Files.fileNames.Add(files);
                CRM.LoadCustomersFromFile(files.CustomerFile);
                Fleet.LoadVehiclesFromFile(files.VehicleFile);
                Fleet.LoadRentalsFromFile(files.RentalFile);
           
            }
            catch (Exception e)
            {
                if (e is IncorrectFileTypeException)
                {
                    Console.WriteLine(e.Message);
                }
                else if (e is IncorrectPathException)
                {
                    Console.WriteLine(e.Message);
                   
                }
                //not enough args are provided
                else if (e is IndexOutOfRangeException)
                {
                    Console.WriteLine("You have not supplied enough filenames in the command line arguments. Please close the program and provide them.\n");
                   
                }
                else if (e is FileNotFoundException)
                {
                    Console.WriteLine(e.Message);
                }
                //if the csv is open whilst user tries to run the program
                else if (e is IOException)
                {
                    Console.WriteLine("Could not load from file as csv is currently open. Please close these files and re-run the program.\n");
                }
                else
                {
                    Console.WriteLine(e.Message);
                }
            }
            Menu.WelcomeMessage();
            Menu.MainMenu();
        }
    }
}
